var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
        this.testzone = {};
		
    },
 
    bindEvents: function() {
        document.addEventListener("deviceready", this.onDeviceReady, false);
        document.addEventListener("pause", this.onPause, false);
        document.addEventListener("resume", this.onResume, false);
        document.addEventListener("online", this.onOnline, false);
        document.addEventListener("offline", this.onOffline, false);
    },

    onDeviceReady: function() {
        console.log("Ready");
		//if (navigator.geolocation) {
		//alert("geo is reayd");
		//} else {
		//alert("geo is not ready");
		//}
		navigator.geolocation.getCurrentPosition(app.onGeoSuccess, app.onGeoError);
        window.addEventListener("batterycritical", app.onBatteryCritical, false);
        window.addEventListener("batterylow", app.onBatteryLow, false);
        window.addEventListener("batterystatus", app.onBatteryStatus, false);
        document.addEventListener("menubutton", app.onMenuButton, false);
        document.addEventListener("searchbutton", app.onSearchButton, false);
        document.addEventListener("backbutton", app.onBackButton, false);
		/*cordova.plugins.diagnostic.isLocationEnabledSetting(function(enabled){
            if(enabled)
            {
                alert("Location Setting is enabled");
            }
            else
            {
                alert("Location Setting is disabled");
            }
        }, function(error){
            alert("The following error occurred: "+error);
        });
		*/
		  // alert("Locatijahdjkhaskjdhsakjhdjs");
//app.checkAvailability();
        app.testzone = document.getElementById("test-zone");
		app.getDeviceInfo();
        app.getConnectionInfo();
        app.runNotificationChain();
    },
    onPause: function() {
        app.testzone.innerHTML += "<br />PAUSED";
    },
    onResume: function() {
        app.testzone.innerHTML += "<br />RESUMED";
    },
    onOnline: function() {
        app.testzone.innerHTML += "<br />ONLINE";
    },
    onOffline: function() {
        app.testzone.innerHTML += "<br />OFFLINE";
    },
    onBackButton: function() {
        app.testzone.innerHTML += "<br />BACK BUTTON";
    },
    onMenuButton: function() {
        app.testzone.innerHTML += "<br />MENU BUTTON";
    },
    onSearchButton: function() {
        app.testzone.innerHTML += "<br />SEARCH BUTTON";
    },
    onBatteryCritical: function() {
        app.testzone.innerHTML += "<br />BATTERY CRITICAL";
    },
    onBatteryLow: function() {
        app.testzone.innerHTML += "<br />BATTERY LOW";
    },
    onBatteryStatus: function(info) {
        app.testzone.innerHTML += "<br />BATTER STATUS: " + info.level + "% and isPlugged: " + info.isPlugged;
    },
	getDeviceInfo: function() {
    	app.testzone.innerHTML += 'Device Name: '     + device.name     + '<br />' + 
                            	'Device Cordova: '  + device.cordova  + '<br />' + 
                            	'Device Platform: ' + device.platform + '<br />' + 
                            	'Device UUID: '     + device.uuid     + '<br />' + 
                            	'Device Version: '  + device.version  + '<br />';
    },
	getConnectionInfo: function() {
    	var networkState = navigator.connection.type;
        var states = {};
        states[Connection.UNKNOWN]  = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI]     = 'WiFi connection';
        states[Connection.CELL_2G]  = 'Cell 2G connection';
        states[Connection.CELL_3G]  = 'Cell 3G connection';
        states[Connection.CELL_4G]  = 'Cell 4G connection';
        states[Connection.NONE]     = 'No network connection';
        
        app.testzone.innerHTML += "Connection type: " + states[networkState];
    },
	
	runNotificationChain: function() {
    	app.testzone.innerHTML += "<br /><br />Starting chain";
    	navigator.notification.alert(
    		'This is an alert message!',  // message
    		app.alertDismissed,         // callback
    		'Alert Box',            // title
    		'See next notification'                  // buttonName
		);
    },
	alertDismissed: function() {
    	navigator.notification.confirm(
        	'Do you want beeps and vibrations?',  // message
        	app.onConfirm,              // callback to invoke with index of button pressed
        	'Confirm Box',            // title
        	'Yes,No'          // buttonLabels
    	);
    },
    onConfirm: function(index) {
    	if(index==2){
    		alert('You selected NO');
    	}else{
    		navigator.notification.beep(2);
    		navigator.notification.vibrate(2500);
    	}
    }, 
	
	onGeoSuccess: function(position) {
						alert('Device readyy');

	    app.testzone.innerHTML += '' +
	    		'Latitude: '          + position.coords.latitude          + '<br />' +
	          	'Longitude: '         + position.coords.longitude         + '<br />' +
	          	'Altitude: '          + position.coords.altitude          + '<br />' +
	          	'Accuracy: '          + position.coords.accuracy          + '<br />' +
	          	'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '<br />' +
	          	'Heading: '           + position.coords.heading           + '<br />' +
	          	'Speed: '             + position.coords.speed             + '<br />' +
	          	'Timestamp: '         + position.timestamp                + '<br />';
		app.lat = position.coords.latitude;
		app.long = position.coords.longitude;
	},
	
	onGeoError: function(error) {
	    alert('code: '    + error.code    + '\n' +'message: ' + error.message + '\n');
	},
	
	
	
	
	checkAvailability: function() {
    cordova.plugins.diagnostic.isGpsLocationAvailable(function(available){
        console.log("GPS location is " + (available ? "available" : "not available"));
        if(!available){
           app.checkAuthorization();
        }else{
            console.log("GPS location is ready to use");
        }
    }, function(error){
        console.error("The following error occurred: "+error);
    });
},

 checkAuthorization: function() {
    cordova.plugins.diagnostic.isLocationAuthorized(function(authorized){
        console.log("Location is " + (authorized ? "authorized" : "unauthorized"));
        if(authorized){
            app.checkDeviceSetting();
        }else{
            cordova.plugins.diagnostic.requestLocationAuthorization(function(status){
                switch(status){
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        console.log("Permission granted");
                        app.checkDeviceSetting();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        console.log("Permission denied");
                        // User denied permission
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        console.log("Permission permanently denied");
                        // User denied permission permanently
                        break;
                }
            }, function(error){
                console.error(error);
            });
        }
    }, function(error){
        console.error("The following error occurred: "+error);
    });
},

 checkDeviceSetting: function() {
    cordova.plugins.diagnostic.isGpsLocationEnabled(function(enabled){
        console.log("GPS location setting is " + (enabled ? "enabled" : "disabled"));
        if(!enabled){
            cordova.plugins.locationAccuracy.request(function (success){
                console.log("Successfully requested high accuracy location mode: "+success.message);
            }, function onRequestFailure(error){
                console.error("Accuracy request failed: error code="+error.code+"; error message="+error.message);
                if(error.code !== cordova.plugins.locationAccuracy.ERROR_USER_DISAGREED){
                    if(confirm("Failed to automatically set Location Mode to 'High Accuracy'. Would you like to switch to the Location Settings page and do this manually?")){
                        cordova.plugins.diagnostic.switchToLocationSettings();
                    }
                }
            }, cordova.plugins.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY);
        }
    }, function(error){
        console.error("The following error occurred: "+error);
    });
}
};
