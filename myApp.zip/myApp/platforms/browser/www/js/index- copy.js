var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
        this.testzone = {};
        this.countDown = "";
        this.count = 0;
    },

    bindEvents: function() {
        document.addEventListener("deviceready", this.onDeviceReady, false);
        document.addEventListener("pause", this.onPause, false);
        document.addEventListener("resume", this.onResume, false);
        document.addEventListener("online", this.onOnline, false);
        document.addEventListener("offline", this.onOffline, false);
    },

    onDeviceReady: function() {
        console.log("Ready");

        window.addEventListener("batterycritical", app.onBatteryCritical, false);
        window.addEventListener("batterylow", app.onBatteryLow, false);
        window.addEventListener("batterystatus", app.onBatteryStatus, false);
        document.addEventListener("menubutton", app.onMenuButton, false);
        document.addEventListener("searchbutton", app.onSearchButton, false);
        document.addEventListener("backbutton", app.onBackButton, false);

        app.testzone = document.getElementById("test-zone");
		app.getDeviceInfo();
        app.getConnectionInfo();
        app.runNotificationChain();
    },
    onPause: function() {
        app.testzone.innerHTML += "<br />PAUSED";
    },
    onResume: function() {
        app.testzone.innerHTML += "<br />RESUMED";
    },
    onOnline: function() {
        app.testzone.innerHTML += "<br />ONLINE";
    },
    onOffline: function() {
        app.testzone.innerHTML += "<br />OFFLINE";
    },
    onBackButton: function() {
        app.testzone.innerHTML += "<br />BACK BUTTON";
    },
    onMenuButton: function() {
        app.testzone.innerHTML += "<br />MENU BUTTON";
    },
    onSearchButton: function() {
        app.testzone.innerHTML += "<br />SEARCH BUTTON";
    },
    onBatteryCritical: function() {
        app.testzone.innerHTML += "<br />BATTERY CRITICAL";
    },
    onBatteryLow: function() {
        app.testzone.innerHTML += "<br />BATTERY LOW";
    },
    onBatteryStatus: function(info) {
        app.testzone.innerHTML += "<br />BATTER STATUS: " + info.level + "% and isPlugged: " + info.isPlugged;
    },
	getDeviceInfo: function() {
    	app.testzone.innerHTML += 'Device Name: '     + device.name     + '<br />' + 
                            	'Device Cordova: '  + device.cordova  + '<br />' + 
                            	'Device Platform: ' + device.platform + '<br />' + 
                            	'Device UUID: '     + device.uuid     + '<br />' + 
                            	'Device Version: '  + device.version  + '<br />';
    },
	getConnectionInfo: function() {
    	var networkState = navigator.connection.type;
        var states = {};
        states[Connection.UNKNOWN]  = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI]     = 'WiFi connection';
        states[Connection.CELL_2G]  = 'Cell 2G connection';
        states[Connection.CELL_3G]  = 'Cell 3G connection';
        states[Connection.CELL_4G]  = 'Cell 4G connection';
        states[Connection.NONE]     = 'No network connection';
        
        app.testzone.innerHTML += "Connection type: " + states[networkState];
    },
	runNotificationChain: function() {
    	app.testzone.innerHTML += "<br /><br />Starting chain";
    	navigator.notification.alert(
    		'This is an alert message!',  // message
    		app.alertDismissed,         // callback
    		'Alert Box',            // title
    		'See next notification'                  // buttonName
		);
    },
	alertDismissed: function() {
    	navigator.notification.confirm(
        	'Do you want beeps and vibrations?',  // message
        	app.onConfirm,              // callback to invoke with index of button pressed
        	'Confirm Box',            // title
        	'Yes,No'          // buttonLabels
    	);
    },
    onConfirm: function(index) {
    	if(index==2){
    		alert('You selected NO');
    	}else{
    		navigator.notification.beep(2);
    		navigator.notification.vibrate(2500);
    	}
    }
};
